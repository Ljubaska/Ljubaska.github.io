"use strict";
var Soccer;
(function (Soccer) {
    class Team {
        constructor(name, color) {
            this.name = name;
            this.color = color;
        }
    }
    Soccer.Team = Team;
})(Soccer || (Soccer = {}));
//# sourceMappingURL=Team.js.map